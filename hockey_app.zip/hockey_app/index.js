
    let submit=document.getElementById("submitbtn");
    let userName=document.getElementById("username");
    let passWord=document.getElementById("password");


setInterval(submitBtn, 1000);
function submitBtn(){
if((userName.value.length<1) || (passWord.value.length<1)){
submit.className="btn disabled";

}else{
submit.className="btn";
}

}


    let checkBtn=document.getElementById("Check");
    let showstate=document.getElementById("info_state");
    let eyeType=document.getElementById("eye");
    let password=document.getElementById("password");

    checkBtn.onclick=changeEye;

    function changeEye(){
        let currentEye=eyeType.className;
        let passwordType=password.type;
        if(currentEye=="fas fa-eye" && passwordType=="password" ){
                //alert ("yoo");
                password.type="text";
                //confirmPassword.type="text";
                eyeType.className="fas fa-eye-slash";
                showstate.innerHTML="Don't ";
        }else if(currentEye=="fas fa-eye-slash" && passwordType=="text"){
                password.type="password";
                //confirmPassword.type="password";
                eyeType.className="fas fa-eye";
                showstate.innerHTML="";  
        }else{
        }

    }





// fizzbuzz


function startGame(){
    const gameContainer=document.getElementById("fizzbuzz");
const showBtn=document.getElementById("showgame");
const exitBtn=document.getElementById("exitgame");
    // alert("yoo");
    let gameContainerValue=gameContainer.style.display;
    
    if(gameContainerValue=="none"){
        showBtn.style.display="none";
        gameContainer.style.display="flex";
        exitBtn.style.display="block";
    
   
    }else{
  

    showBtn.style.display="block";
    gameContainer.style.display="none";
    exitBtn.style.display="none";

    }

}


    
    function fizzBuzz(){
        let output=document.getElementById("output");
        let input=document.forms["fizz"]["fizzbuzz"].value;
        if(input.length==0){
            output.innerHTML="";
        }
    
        else if(input % 3 == 0 && input % 5 == 0){
            output.innerHTML="Fizz Buzz";
        }else if( input % 3 == 0){
            output.innerHTML="Fizz";
        }else if(input % 5 == 0){
            output.innerHTML="Buzz";
        }else{
            output.innerHTML=input;
        }

    }
